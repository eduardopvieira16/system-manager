package br.com.vieira.system_manager_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
